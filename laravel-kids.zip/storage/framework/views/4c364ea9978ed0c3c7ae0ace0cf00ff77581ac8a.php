<div class="footer">
    <p>&copy; 2026 Kids WordPress Theme. All rights reserved.</p>
    <div class="social-media">
        <a href="#" class="facebook">Facebook</a>
        <a href="#" class="linkedin">LinkedIn</a>
        <a href="#" class="twitter">Twitter</a>
    </div>
</div>
<?php /**PATH C:\Users\USER\laravel-kids\resources\views/layouts/footer.blade.php ENDPATH**/ ?>