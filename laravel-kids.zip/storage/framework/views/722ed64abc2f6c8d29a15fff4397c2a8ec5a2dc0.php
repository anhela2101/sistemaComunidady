<div class="container fixed-top px-3">
    <nav class="navbar navbar-expand-lg navbar-glass">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="<?php echo e(route('home')); ?>">
                <div class="bg-success text-white rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                    <i class="fa-solid fa-leaf"></i>
                </div>
                <span class="font-serif fw-bold text-dark">TiketRural</span>
            </a>
            
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
                <i class="fa-solid fa-bars-staggered text-primary"></i>
            </button>

            <div class="collapse navbar-collapse" id="navContent">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('project')); ?>">Proyecto</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Servicios</a>
                        <ul class="dropdown-menu border-0 shadow-lg rounded-4 p-2 mt-3">
                            <li><a class="dropdown-item rounded-3 py-2 text-muted" href="<?php echo e(route('services.social')); ?>">🏛️ Centros Sociales</a></li>
                            <li><a class="dropdown-item rounded-3 py-2 text-muted" href="<?php echo e(route('services.associations')); ?>">🎉 Fiestas y Eventos</a></li>
                            <li><a class="dropdown-item rounded-3 py-2 text-muted" href="<?php echo e(route('services.municipal')); ?>">🎭 Cultura Municipal</a></li>
                            <li><a class="dropdown-item rounded-3 py-2 text-muted" href="<?php echo e(route('services.tourism')); ?>">🏡 Turismo Rural</a></li>
                            <li><a class="dropdown-item rounded-3 py-2 text-muted" href="<?php echo e(route('services.travel')); ?>">🚌 Viajes</a></li>
                        </ul>
                    </li>
                    <li class="nav-item ms-lg-3 mt-3 mt-lg-0">
                        <a href="<?php echo e(route('contact')); ?>" class="btn btn-custom btn-sm">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div><?php /**PATH C:\Users\USER\laravel-kids\resources\views/partials/header.blade.php ENDPATH**/ ?>