<nav>
    <div class="logo">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Kids WordPress Theme Logo">
        </a>
    </div>

    <ul class="nav-menu">
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('/about-us')); ?>">About Us</a></li>
        <li><a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
        <li><a href="<?php echo e(url('/programs')); ?>">Programs</a></li>
        <li><a href="<?php echo e(url('/blog')); ?>">Blog</a></li>
        <li><a href="<?php echo e(url('/shop')); ?>">Shop</a></li>
    </ul>
</nav>

<?php /**PATH C:\Users\USER\laravel-kids\resources\views/layouts/header.blade.php ENDPATH**/ ?>