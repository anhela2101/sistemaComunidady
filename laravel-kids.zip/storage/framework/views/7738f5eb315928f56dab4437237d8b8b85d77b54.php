

<?php $__env->startSection('title', 'Kids WordPress Theme'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Sección del Slider -->
    <div class="slider">
        <img src="<?php echo e(asset('images/slider.jpg')); ?>" alt="Kids WordPress Theme Slider">
        <div class="slider-text">
            <h1>Your Kids Should Have Fun, and Educations.</h1>
            <a href="<?php echo e(url('/programs')); ?>" class="btn btn-primary">Get Started</a>
        </div>
    </div>

    <!-- Sección de Servicios -->
    <div class="services">
        <h2>Our Services</h2>
        <div class="service-box">
            <img src="<?php echo e(asset('images/icon1.png')); ?>" alt="Call us Icon">
            <h3>Call Us</h3>
            <p>+1 (915) 656 2552</p>
        </div>
        <div class="service-box">
            <img src="<?php echo e(asset('images/icon2.png')); ?>" alt="Email Icon">
            <h3>Email</h3>
            <p>info@kidzythemes.com</p>
        </div>
        <div class="service-box">
            <img src="<?php echo e(asset('images/icon3.png')); ?>" alt="Address Icon">
            <h3>Address</h3>
            <p>320 Green St. Los Angeles, CA</p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\laravel-kids\resources\views/kids.blade.php ENDPATH**/ ?>