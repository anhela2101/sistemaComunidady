<footer class="mt-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4">
                <h3 class="text-white mb-3 font-serif">Laura Mota Maillo</h3>
                <p class="opacity-75">Gestión cultural, eventos y activación rural en el <strong>Camín Real de la Mesa</strong>. Un proyecto para crear comunidad y combatir la despoblación.</p> </div>
            <div class="col-lg-2 offset-lg-1">
                <h5 class="text-secondary mb-3">Servicios</h5>
                <ul class="list-unstyled opacity-75 d-grid gap-2">
                    <li><a href="<?php echo e(route('services.social')); ?>">Centros Sociales</a></li>
                    <li><a href="<?php echo e(route('services.tourism')); ?>">Turismo Rural</a></li>
                    <li><a href="<?php echo e(route('services.associations')); ?>">Fiestas</a></li>
                </ul>
            </div>
            <div class="col-lg-2">
                <h5 class="text-secondary mb-3">Proyecto</h5>
                <ul class="list-unstyled opacity-75 d-grid gap-2">
                    <li><a href="<?php echo e(route('project')); ?>">Misión</a></li>
                    <li><a href="<?php echo e(route('services.travel')); ?>">Viajes</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">Contacto</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h5 class="text-secondary mb-3">Contacto</h5>
                <p class="opacity-75"><i class="fa-solid fa-location-dot me-2"></i> Asturias, España</p>
                <p class="opacity-75"><i class="fa-solid fa-envelope me-2"></i> info@tiketrural.com</p>
            </div>
        </div>
        <hr class="border-secondary my-5 opacity-25">
        <div class="text-center small opacity-50">
            © 2026 Proyecto TiketRural. Financiado con apoyo LEADER. </div>
    </div>
</footer><?php /**PATH C:\Users\USER\laravel-kids\resources\views/partials/footer.blade.php ENDPATH**/ ?>