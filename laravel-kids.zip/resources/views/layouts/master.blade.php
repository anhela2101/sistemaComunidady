<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TiketRural | Activación Rural - Camín Real de la Mesa</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&family=Playfair+Display:ital,wght@0,600;1,600&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #1A4D2E;   /* Verde Profundo */
            --secondary: #E0A458; /* Dorado Tierra */
            --accent: #FF6B6B;    /* Coral */
            --light: #F9FBF9;
            --dark: #0D2112;
            --glass: rgba(255, 255, 255, 0.85);
            --glass-border: rgba(255, 255, 255, 0.6);
        }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--light);
            color: #444;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, h5 { font-family: 'Playfair Display', serif; color: var(--primary); }

        /* --- ANIMACIONES AVANZADAS --- */
        
        /* 1. Zoom Lento (Ken Burns para Hero) */
        @keyframes zoomSlow {
            0% { transform: scale(1); }
            100% { transform: scale(1.2); }
        }
        .animate-ken-burns { animation: zoomSlow 25s alternate infinite linear; }

        /* 2. Levitación Estándar */
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-12px); }
            100% { transform: translateY(0px); }
        }
        .animate-float { animation: float 5s ease-in-out infinite; }

        /* 3. Flotación Vertical (Para Collage) */
        @keyframes floatVertical {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        .animate-float-y { animation: floatVertical 7s ease-in-out infinite; }

        /* 4. Flotación Horizontal (Para Collage) */
        @keyframes floatHorizontal {
            0%, 100% { transform: translateX(0); }
            50% { transform: translateX(15px); }
        }
        .animate-float-x { animation: floatHorizontal 8s ease-in-out infinite reverse; }

        /* 5. Shine Effect (Brillo al pasar mouse) */
        .hover-shine { position: relative; overflow: hidden; }
        .hover-shine::before {
            content: ''; position: absolute; top: 0; left: -75%; z-index: 2; display: block;
            width: 50%; height: 100%; background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 100%);
            transform: skewX(-25deg); transition: .75s;
        }
        .hover-shine:hover::before { left: 125%; }

        /* --- COMPONENTES DE DISEÑO --- */

        /* Navbar Flotante Glassmorphism */
        .navbar-glass {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-radius: 50px;
            padding: 10px 30px;
            margin-top: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            border: 1px solid rgba(255,255,255,0.5);
            transition: all 0.3s;
        }

        .nav-link {
            font-weight: 700; color: var(--primary) !important;
            text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px;
            padding: 0 15px !important; position: relative;
        }
        .nav-link::after {
            content: ''; position: absolute; bottom: 0; left: 50%; width: 0; height: 2px;
            background: var(--secondary); transition: 0.3s; transform: translateX(-50%);
        }
        .nav-link:hover::after { width: 60%; }

        /* Tarjetas Glassmorphism */
        .card-glass {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.05);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .card-glass:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(26, 77, 46, 0.15);
            border-color: var(--secondary);
            background: #fff;
        }

        /* Botones Premium */
        .btn-custom {
            background: var(--primary); color: white; border-radius: 50px;
            padding: 12px 35px; font-weight: 700; border: 2px solid var(--primary);
            transition: 0.3s;
        }
        .btn-custom:hover {
            background: transparent; color: var(--primary);
            box-shadow: 0 5px 15px rgba(26, 77, 46, 0.2);
        }

        /* --- ESTILOS PARA GALERÍA DINÁMICA (NUEVO) --- */
        .img-hover-zoom {
            position: relative;
            overflow: hidden;
            border-radius: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            height: 100%;
        }
        .img-hover-zoom img {
            transition: transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            width: 100%; height: 100%; object-fit: cover;
        }
        .img-hover-zoom:hover img { transform: scale(1.1); }
        
        .img-overlay {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(to top, rgba(13, 33, 18, 0.8) 0%, rgba(0,0,0,0) 60%);
            display: flex; flex-direction: column; justify-content: flex-end;
            padding: 2rem; opacity: 0; transition: all 0.4s ease;
            transform: translateY(20px);
        }
        .img-hover-zoom:hover .img-overlay { opacity: 1; transform: translateY(0); }
        .img-overlay h4 { color: white; margin-bottom: 5px; font-size: 1.5rem; }
        .img-overlay p { color: rgba(255,255,255,0.8); font-size: 0.9rem; margin: 0; }

        /* Footer */
        footer {
            background: var(--dark); color: rgba(255,255,255,0.7);
            padding: 80px 0 40px; border-top-left-radius: 60px; border-top-right-radius: 60px;
        }
        footer a { color: inherit; text-decoration: none; transition: 0.3s; }
        footer a:hover { color: var(--secondary); padding-left: 5px; }
    </style>
</head>
<body>

    @include('partials.header')

    <main>
        @yield('content')
    </main>

    @include('partials.footer')

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script> AOS.init({ duration: 1000, once: true, offset: 50 }); </script>
</body>
</html>